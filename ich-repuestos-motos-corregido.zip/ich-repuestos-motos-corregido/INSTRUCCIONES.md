# ICH – Repuestos para motos (versión adaptada a tu Supabase)

Esta versión está adaptada a las tablas que ya existen en tu proyecto Supabase. **No crea tablas nuevas y no debes ejecutar el antiguo `supabase-schema.sql`.**

## Tablas que utiliza
- `categorias`: `id`, `nombre` (y otros campos que ya tengas).
- `marcas`: `id`, `nombre`, `created_at`.
- `motocicletas`: `id`, `marca`, `modelo`, `anio_desde`, `anio_hasta`, `created_at`.
- `productos`: `id`, `referencia`, `nombre`, `descripcion`, `categoria_id`, `marca_id`, `precio`, `imagenes` (arreglo de texto), `activo`, `created_at`, `updated_at`.

Las relaciones `productos.categoria_id` y `productos.marca_id` deben estar relacionadas mediante claves foráneas con `categorias.id` y `marcas.id` para que se muestren los nombres en la tienda.

## Panel de administración
Abre `admin.html` después de publicar:
- **Productos:** crear, editar, publicar/ocultar y borrar productos.
- **Marcas:** agregar, editar y borrar marcas. El panel impide borrar una marca si algún producto la está utilizando.
- **Motocicletas:** agregar manualmente cualquier marca, modelo y rango de años; también permite editar y borrar.

## Conexión de Supabase
En `config.js`, reemplaza los dos valores de ejemplo por:
- `supabaseUrl`: Project URL de Supabase.
- `supabaseAnonKey`: clave pública anon/publishable.

No coloques `service_role`, contraseñas ni claves secretas en los archivos del sitio.

## Almacenamiento de fotografías
El panel espera un bucket público de Supabase Storage llamado `product-images`, con permiso de lectura pública y permisos de carga para usuarios autenticados. Si el bucket o las políticas no existen, hay que configurarlos desde Storage/RLS antes de probar la carga de imágenes.

## Acceso privado
El panel utiliza Supabase Authentication. Debe existir un usuario administrador creado manualmente y el registro público debe permanecer desactivado. Las políticas RLS deben permitir a `authenticated` gestionar las tablas `productos`, `marcas` y `motocicletas`; la tienda pública solo necesita leer categorías y productos activos, además de sus marcas.

## Publicar sin créditos de agentes Netlify
1. Descomprime esta carpeta en tu computador.
2. Abre `config.js` y configura Project URL y anon/publishable key.
3. Sube el contenido de la carpeta `ich-repuestos-motos` a Netlify Drop o al método de publicación de archivos que ya utilizaste.
4. Prueba la tienda y entra a `admin.html` para probar el panel.

No se han incluido credenciales privadas. La publicación de archivos estáticos no requiere utilizar el agente de IA de Netlify.

## Importante
Esta versión no modifica la estructura de Supabase. La administración de compatibilidad de productos con motocicletas queda pendiente de revisar la estructura de la tabla `compatibilidad`; no se asume ningún nombre de columna que todavía no hayamos confirmado.


## Actualización correctiva (25/11/2026)
Esta carpeta incluye los archivos con identificadores de versión para evitar que el navegador reutilice scripts antiguos. Para actualizar Netlify, publica nuevamente TODO el contenido de esta carpeta (incluida la carpeta `assets`) y no solo `admin.js`. Después abre `/admin.html` y recarga con Ctrl+F5.
